/*
 * Olark wrapper for jQuery mmenu
 * Include this file after including the jquery.mmenu plugin for default Olark support.
 */
!function(n){var o="mmenu";n[o].configuration.offCanvas.noPageSelector.push("#olark")}(jQuery);